#pragma once
/* Author: Elliot Gong
   Date: 1/17/2022
   Purpose: Test out the usage of functions and header files.
   Restrictions: Declare the PrintName function signature.*/
void PrintName();
