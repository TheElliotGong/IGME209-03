#pragma once
//Include all the necessary header files, including the box2d api.
#include <iostream>
#include <cstring>
#include "include\Box2D\Box2D.h"
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctime>
#include <math.h>
#include<iomanip>
#include <chrono>
using namespace std;
using namespace chrono;

/*Author: Elliot Gong
* Purpose: Declare the functions needed for the Gravity Snake game.
* Restrictions: Must use the required functions.
* Date: 2/20/2022
*/

//Declare all functions.
void Update(b2Body* player, b2World* world, float& targetX, float& targetY, int& targetCount);
void Display(float& targetX, float& targetY, float playerX, float playerY, int& targetCount);
void ApplyForces(int key, b2Body* player);
void MoveTarget(float& xPos, float& yPos);
//These header functions will be used to help get a random float within a range and determine if a
//float is within a range.
float GenerateRandomNumber(float min, float max);
bool WithinRange(float value, float min, float max);