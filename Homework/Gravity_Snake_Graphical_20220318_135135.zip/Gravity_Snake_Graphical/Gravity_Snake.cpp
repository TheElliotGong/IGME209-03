// Gravity_Snake.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

//Include the snake header file.
#include "snake.h"

/*Author: Elliot Gong
*Purpose: Simulate the Snake Game in Box2D and add gravity to make the snake "fall". Display the game 
*using SFML. Record the time taken to hit the 2 targets to score the player
*Restrictions: Must have the snake hit at least 10 targets and end the program when it does. Also convert
* Box2D's Cartesian coordinate system to be drawn in SFML's pixel coordinate system.
*Date:3/16/2022*/

//Declare the neessary global variables in addition to some that will aid with function operations.
int index = 0;
b2Vec2* targetLocations;
b2Vec2 currentPosition;
int targetCount;
int keyPress = 0;
bool targetsLeft;
//Declare a function typedef used to applying forces to the player.
typedef void (*forceFunctionPointer)(b2Body*);
forceFunctionPointer playerFunctionPointer;
static const float scale = 30.0f;

int main()
{
	//Create the sfml window.
	sf::RenderWindow window(sf::VideoMode(800, 600), "Gravity Snake");
	window.setTitle("Gravity Snake: Graphical Edition");
	window.setFramerateLimit(60);
	//Reset random so different values will always be randomly generated each time.
	srand(static_cast <unsigned> (time(0)));
	//Create the b2world
	b2Vec2 gravity(0, -6.f);
	b2World* world = new b2World(gravity);
	//Create the ground.
	b2BodyDef* groundBody = new b2BodyDef;
	groundBody->position.Set(400.f / scale, 4.f/scale);
	groundBody->type = b2_staticBody;
	b2Body* ground = world->CreateBody(groundBody);
	//Create the ceiling.
	b2BodyDef* ceilingBody = new b2BodyDef;
	ceilingBody->position.Set(400.f / scale, 596.f/scale);
	ceilingBody->type = b2_staticBody;
	b2Body* ceiling = world->CreateBody(ceilingBody);
	//Create the shape for the ground and ceiling bodies.
	b2PolygonShape* box = new b2PolygonShape;
	box->SetAsBox(400.f / scale, 4.f / scale);
	//create the fixture definition for the ground & ceiling.
	b2FixtureDef groundAndCeilingFixture;
	groundAndCeilingFixture.density = 0.f;
	groundAndCeilingFixture.shape = box;
	//Assign the fixtures to the ground and ceiling.
	ground->CreateFixture(&groundAndCeilingFixture);
	ceiling->CreateFixture(&groundAndCeilingFixture);
	//Create the left wall.
	b2BodyDef* leftWallBody = new b2BodyDef;
	leftWallBody->position.Set(4.f / scale, 300.f / scale);
	leftWallBody->type = b2_staticBody;
	b2Body* leftWall = world->CreateBody(leftWallBody);
	//Create the right wall.
	b2BodyDef* rightWallBody = new b2BodyDef;
	rightWallBody->position.Set(796.f / scale, 300.f / scale);
	rightWallBody->type = b2_staticBody;
	b2Body* rightWall = world->CreateBody(rightWallBody);
	//Define the walls' shape.
	b2PolygonShape* wallShape = new b2PolygonShape;
	wallShape->SetAsBox(4.f / scale , 292.f/scale);
	//Define the walls' fixture.
	b2FixtureDef wallFixture;
	wallFixture.density = 0.f;
	wallFixture.shape = wallShape;
	//Assign the fixtures to the walls.
	rightWall->CreateFixture(&wallFixture);
	leftWall->CreateFixture(&wallFixture);
	//Create the playable snake as a dynamic body and set its position
	b2BodyDef* snake = new b2BodyDef;
	snake->type = b2_dynamicBody;
	snake->position.Set(400.f / scale, 200.f / scale);
	b2Body* player = world->CreateBody(snake);
	//Define the snake's shape.
	b2CircleShape snakeShape;
	snakeShape.m_radius = 8.f / scale;
	//Define the snake's fixture.
	b2FixtureDef fixtureDef;
	fixtureDef.shape = &snakeShape;
	fixtureDef.density = 0.4f;
	fixtureDef.friction = 1.0f;
	player->CreateFixture(&fixtureDef);
	//Set up the targets.
	SetUpTargets();
	//Define the sfml shape of the player.
	sf::CircleShape snakePlayer(8.f);
	snakePlayer.setOrigin(8.f, 8.f);
	snakePlayer.setPosition(400, 300);
	snakePlayer.setFillColor(sf::Color::Red);
	//Define the sfml shape of the target.
	sf::RectangleShape targetShape(sf::Vector2f(10.0f, 10.0f));
	targetShape.setOrigin(5, 5);
	targetShape.setPosition(currentPosition.x * scale, 600 - currentPosition.y * scale);
	targetShape.setFillColor(sf::Color::Yellow);
	//Define the sfml shape of the ground and ceiling.
	sf::RectangleShape groundShape(sf::Vector2f(800.f, 8.f));
	groundShape.setOrigin(400.f, 4.f);
	groundShape.setFillColor(sf::Color::Green);
	groundShape.setPosition(groundBody->position.x * scale, 600 - (groundBody->position.y * scale));
	//Define the sfml shape of the left and right wall.
	sf::RectangleShape wallFigure(sf::Vector2f(8.f, 584.f));
	wallFigure.setOrigin(4.f, 292.f);
	wallFigure.setFillColor(sf::Color::Green);
	wallFigure.setPosition(leftWallBody->position.x * scale, leftWallBody->position.y * scale);
	//Record the current time at start of the game, after setting up all the box2D objects.
	auto startTime = steady_clock::now();
	//Keep the game playing until the player has hit all targets or closed the window.
	while (window.isOpen() && targetsLeft)
	{
		//Check if player closes the window manually.
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}
		//Clear the canvas, check for player keyboard input, and see if the snake has 
		//collided with the current target.
		window.clear(sf::Color::Black);
		ProcessInput(player, keyPress, world);
		CheckCollision(snake, targetShape, snakePlayer);
		world->Step(1.0f / 60.0f, 8, 3);
		//Change the position of the sfml snake shape according to the box2 snake object
		snakePlayer.setPosition(player->GetPosition().x * scale, 600 - (player->GetPosition().y * scale));
		window.draw(snakePlayer);
		//Draw the target
		window.draw(targetShape);
		//Draw the ground shape.
		window.draw(groundShape);
		//Move the ground shape to the top so it becomes the "ceiling" and draw that.
		groundShape.setPosition(ceilingBody->position.x * scale, 600 - (ceilingBody->position.y * scale));
		window.draw(groundShape);
		groundShape.setPosition(groundBody->position.x * scale, 600 - (groundBody->position.y * scale));
		//Move the ground shape back to its original place on the "floor"
		//Draw the "left" wall first.
		window.draw(wallFigure);
		//Move the wall to the right so we can draw the "right" wall.
		wallFigure.setPosition(rightWallBody->position.x * scale, rightWallBody->position.y * scale);
		window.draw(wallFigure);
		//Move the wall back its original position on the left.
		wallFigure.setPosition(leftWallBody->position.x * scale, leftWallBody->position.y * scale);
		//Display all items.
		window.display();
	}
	//Have the player stop moving in box2d when the game is over.
	StopMoving(*player);
	//Track the current time at the end of the program, after the player has hit 2 targets.
	auto endTime = steady_clock::now();
	//Determine the time spent trying to get the snake to hit the 2 targets.
	long time = duration_cast<seconds>(endTime - startTime).count();
	//Based on the amount of time spent on the game, print out different messages.
	//If they complete the game within 20 seconds, give them a "3 star" grade.
	if (time <= 45 && index + 1 == targetCount)
	{
		cout << "Time taken to hit all targets: " << time << " seconds. Good job! You earned 3 stars!\n";
	}
	//If they complete the game within 40 seconds, give them a "2 star" grade.
	else if (45 < time <= 72 && index + 1== targetCount)
	{
		cout << "Time taken to hit all targets: " << time << " seconds. Not bad! You earned 2 stars!\n";
	}
	//If they take longer than 40 seconds, give them a "1 star" grade.
	else if (72 < time && index + 1 == targetCount)
	{
		cout << "Time taken to hit all targets: " << time << " seconds. So close! You earned 1 star!\n";
	}
	cout << "Thanks for playing!";
	//Delete the pointer objects.
	delete[] targetLocations;
	delete groundBody;
	delete ceilingBody;
	delete leftWallBody;
	delete rightWallBody;
	//End the program.
	return 0;
}
/// <summary>
/// This function takes in player input and moves the box2d player object based on the key pressed.
/// </summary>
/// <param name="player">The box2d body object that will be affected by the controls.</param>
/// <param name="keyPresses">The int checking to see if any key has been pressed.</param>
void ProcessInput(b2Body* player, int& keyPresses, b2World* world)
{
	//Attach appropriate functions to the function pointer based on keyboard input. Also update
	//the keypresses parameter to indicate a key has been pressed.

	//If the space key is pressed, call the reverse gravity method.
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
	{
		ReverseGravity(world);
	}
	//Attach the "moveup" function to the pointer if the up arrow key is pressed.
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	{
		keyPresses = 1;
		playerFunctionPointer = &ApplyForceUp;
	}
	//Attach the "movedown" function to the pointer if the down arrow key is pressed.
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
		keyPresses = 1;
		playerFunctionPointer = &ApplyForceDown;
	}
	//Attach the "moveleft" function to the pointer if the left arrow key is pressed.
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	{
		keyPresses = 1;
		playerFunctionPointer = &ApplyForceLeft;
	}
	//Attach the "moveright" function to the pointer if the right arrow key is pressed.
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		keyPresses = 1;
		playerFunctionPointer = &ApplyForceRight;
	}
	//Finally, call the pointer if a function is attached and if a control key has actually been pressed.
	if (playerFunctionPointer != nullptr && keyPresses == 1)
	{
		playerFunctionPointer(player);
	}
	//Reset the int parameter to prepare for the next update cycle.
	keyPress = 0;
}
/// <summary>
/// This function applies an upward force on the player body.
/// </summary>
/// <param name="player">the body that will be affected by the force.</param>
void ApplyForceUp(b2Body* player)
{
	player->ApplyForceToCenter(b2Vec2(0.0f, 30/scale), false);
}

/// <summary>
/// This function applies a downward force on the player body.
/// </summary>
/// <param name="player">the body that will be affected by the force.</param>
void ApplyForceDown(b2Body* player)
{
	player->ApplyForceToCenter(b2Vec2(0.0f, -30/scale), false);
}
/// <summary>
/// This function applies a force towards the body's left.
/// </summary>
/// <param name="player">the body that will be affected by the force.</param>
void ApplyForceLeft(b2Body* player)
{
	player->ApplyForceToCenter(b2Vec2(-20/scale, 0.0f), false);
}

/// <summary>
/// This function applies a force toward the body's right.
/// </summary>
/// <param name="player">the body that will be affected by the force.</param>
void ApplyForceRight(b2Body* player)
{
	player->ApplyForceToCenter(b2Vec2(20/scale, 0.0f), false);
}
/// <summary>
/// This function makes the player stop moving entirely.
/// </summary>
/// <param name="player">the body that will be affected.</param>
void StopMoving(b2Body& player)
{
	player.SetLinearVelocity(b2Vec2_zero);
}
/// <summary>
/// This function reverses the gravity of the desired world.
/// </summary>
/// <param name="world">the world that will have its gravity reversed.</param>
void ReverseGravity(b2World* world)
{
	//Reverse the y component of the world's gravity.
	world->SetGravity(b2Vec2(0, -1 * world->GetGravity().y));
}
/// <summary>
/// This function will take user input and set up a dynamic array of random vector positions that will
/// be used for the target's location.
/// </summary>
void SetUpTargets()
{
	string input;
	//Ask the user for the desired target count. Store input in a local string variable.
	do
	{
		cout << "How many targets do you want? It must be at least 10: ";
		getline(cin, input);
		//Parse an int from the input if possible.
		targetCount = atoi(input.c_str());
		//Keep asking for valid input.
	} while (targetCount < 10 || input.empty() == true);
	//Add an extra target to the array.
	targetCount += 1;
	targetLocations = new b2Vec2[targetCount];
	//Fill out the dynamic array with randomly generated 2D vectors.
	for (int i = 0; i < targetCount; i++)
	{
		if (i == targetCount - 1)
		{
			//The last target should be in the top left corner of the screen.
			targetLocations[i] = b2Vec2(13.f/scale, 587.f/scale);
		}
		else
		{
			//Otherwise, the random vectors should fit within the defined play area.
			targetLocations[i] = b2Vec2(GenerateRandomNumber(13.f, 787.f)/scale, GenerateRandomNumber(13.f, 587.f)/scale );
		}
	}
	//Set current position of the target as the first element in the vector array.
	currentPosition = targetLocations[0];
	//In addition, set the global bool variable to true, indicating there are targets left to hit.
	targetsLeft = true;
}
/// <summary>
/// This function moves the current target location to the next valid location and returns a bool
/// based on if the current target is the last one.
/// </summary>
/// <param name="targetBodyDef">The target's box2D body definition that will potentially be moved.</param>
/// <param name="targetShape">The target's SFML shape that will potentially be moved.</param>
/// <returns></returns>
bool SelectNextTarget( sf::RectangleShape& targetShape)
{
	//Return false if the current index has reached the end of the vector array.
	if (index == targetCount - 1)
	{
		return false;
	}
	//Otherwise, increment the index and change the currentposition vector.
	//Set the positions for the body and the sfml shape to the new current vector and return true.
	else
	{
		index++;
		currentPosition = targetLocations[index];
		targetShape.setPosition(currentPosition.x * scale, 600 - (currentPosition.y * scale));
		return true;
	}
}
/// <summary>
/// This function checks if the snake has collided with a target.
/// </summary>
/// <param name="player"></param>
/// <param name="target"></param>
/// <param name="targetBody"></param>
/// <param name="currentPosition"></param>
/// <param name="targetShape"></param>
void CheckCollision(b2BodyDef* playerDef, sf::RectangleShape& targetShape, sf::CircleShape playerShape)
{
	//If the player is on the target's left.
	if (BodiesCollided(targetShape, playerShape))
	{
		//Update the global bool variable 
		targetsLeft = SelectNextTarget(targetShape);
	}
}
/// <summary>
/// This function helps generate a random float within a defined range.
/// </summary>
/// <param name="min">The maximum possible value of the randomly generated </param>
/// <param name="max">The minimum possible value of the randomly generated float.</param>
/// <returns></returns>
float GenerateRandomNumber(float min, float max)
{
	//Calculate the random float and round it out.
	float value = min + (rand()) / (RAND_MAX / (max - min));
	value = float(int(value * 10 + 0.5)) / 10;
	return value;
}
/// <summary>
/// This function checks the player and target bodies are colliding.
/// </summary>
/// <param name="value">The float that'll be checked to see if it's within the range.</param>
/// <param name="min">The minimum value of the range.</param>
/// <param name="max">The maximum value of the range.</param>
/// <returns></returns>
bool BodiesCollided(sf::RectangleShape target, sf::CircleShape player)
{
	//Calculate the absolute difference between the bodies' x and y coordinates.
	float xDistance = abs(player.getPosition().x - target.getPosition().x);
	float yDistance = abs(player.getPosition().y - target.getPosition().y);
	//Check to see if the 2 bodies aren't colliding each other.
	if (xDistance > 13.f || yDistance > 13.f) { return false; }
	//Check to see if bodies are colliding on any of the 4 sides: left, right, top, and bottom.
	else if (xDistance <= 13.f && yDistance <= 13.f) { return true; }
	//Check to see if the 2 bodies are colliding via their corners.
	float cornerDistance = sqrt(pow(xDistance, 2) + pow(yDistance, 2));
	return (cornerDistance <= (5.f * sqrt(2) + 8.f)); 
}
